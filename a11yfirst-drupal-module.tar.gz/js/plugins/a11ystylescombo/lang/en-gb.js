/**
* Copyright (c) 2018 University of Illinois - Jon Gunderson and Nicholas Hoyt. All rights reserved.
* For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'a11ystylescombo', 'en-gb', {
  label:             'Inline Style',
  helpLabel:         'Help',
  removeStylesLabel: 'Remove styles',
  panelTitle:        'Select inline style',
  panelTitle1:       'Block Styles',
  panelTitle2:       'Inline Styles',
  panelTitle3:       'Object Styles'
} );
